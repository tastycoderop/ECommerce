/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package package2;

public class ECommerce {

    public static void main(String[] args) {
         
    }
}
